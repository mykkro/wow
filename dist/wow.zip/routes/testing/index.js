'use strict';

module.exports = {

    '/testing': function(req, res){
        res.send("It's test page of my app. It use GET method.");
    }

};