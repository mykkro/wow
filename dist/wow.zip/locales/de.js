{
	"Hello!": "Guten Tag!",
	"afternoon": "nachmittag",
	"midday": "mittag",
	"This will quit the application. Are you sure?": "Beenden?",
	"morning": "vormittag",
	"dynamic string": "dynamic string",
	"Exit": "Beenden",
	"Are you sure?": "Sind Sie sicher?",
	"Yes": "Ja",
	"No": "Nein",
	"Remove": "Löschen",
	"Remove this item?": "Löschen?"
}