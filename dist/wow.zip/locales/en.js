{
	"Hello!": "Hello!",
	"afternoon": "afternoon",
	"midday": "midday",
	"morning": "morning",
	"This will quit the application. Are you sure?": "This will quit the application. Are you sure?",
	"Exit": "Exit",
	"Are you sure?": "Are you sure?",
	"Yes": "Yes",
	"No": "No",
	"Remove": "Remove",
	"Remove this item?": "Remove this item?"	
}