var mustache = require("mustache")
var xmlutils = require("./xmlutils")

/* Shared object between widgets */
/* Provides access to main screen (stage) */
var Stage = {

  appendSvg: function(tpl, data) {
    var elem = this.buildSvg(tpl, data)
    var svg = document.getElementById("svg-main")
    svg.appendChild(elem);
    return elem
  },

  /* Fills SVG template with data */
  buildSvg: function(tpl, data) {
    var out = mustache.render(tpl, data)
    var doc = xmlutils.tryParseXML(out)
    var svg = document.getElementById("svg-main")
    var elem = svg.ownerDocument.importNode(doc.documentElement, true)
    return elem
  }

}

module.exports = Stage