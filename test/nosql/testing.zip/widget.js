var Base = require("basejs")
var d3 = require("d3")

var xmlns = "http://www.w3.org/2000/svg";

var Widget = Base.extend({
  /* offset */
  x: 0,
  y: 0,
  /* containing group - DOM element */
  element: null,
  /* containing group - D3 selection */
  $element: null,  
  constructor: function(stage, data) {
      this.stage = stage
      this.data = data || {}
      this.element = document.createElementNS(xmlns, "g");
      this.$element = d3.select(this.element)
  },
  setPosition: function(x, y) {
    this.x = x;
    this.y = y;
    this._updateTransform()
  },
  _updateTransform: function() {
    var trs = "translate("+this.x+" "+this.y+")"
    this.element.setAttribute('transform',trs);
  }
})

module.exports = Widget
